<?php

declare(strict_types=1);

namespace Sillbeam\Core\Module;

use Sillbeam\Core\Architecture\ArchitectureValidationException;
use Sillbeam\Core\Architecture\DiscoveryOptions;
use Sillbeam\Core\Architecture\IdDeriver;
use Sillbeam\Core\Architecture\SourceInspector;
use Sillbeam\Core\Module\Attribute\SillbeamModule;
use Sillbeam\Core\Project\ProjectDefinition;

/**
 * Discovers shared and Project-owned module descriptors and rejects ambiguous ownership.
 *
 * @internal
 */
final readonly class ModuleDiscovery
{
    public function __construct(private SourceInspector $inspector = new SourceInspector())
    {
    }

    /** @param array<class-string, ProjectDefinition> $projects
     * @return array<class-string, ModuleDefinition>
     */
    public function discover(DiscoveryOptions $options, array $projects): array
    {
        $modules = [];
        foreach ($this->inspector->descriptors($options, SillbeamModule::class) as $file => $class) {
            $directory = \dirname($file);
            foreach ($projects as $project) {
                if (str_starts_with($project->directory.'/', $directory.'/')) {
                    throw ArchitectureValidationException::fatal('discovery.project_inside_module', 'Project cannot be inside module area: '.$project->class.' and '.$class, ['file' => $file, 'module' => $class]);
                }
            }
            $owner = null;
            $inProjectRoot = false;
            foreach ($options->projectRoots as $root) {
                $inProjectRoot = $inProjectRoot || $root->contains($file);
            }
            foreach ($projects as $project) {
                if (str_starts_with($directory.'/', $project->directory.'/') && $directory !== $project->directory) {
                    $owner = $project->class;
                }
            }
            if ($inProjectRoot && null === $owner) {
                throw ArchitectureValidationException::fatal('discovery.owner_missing', 'Module "'.$class.'" has no owning project.', ['file' => $file, 'module' => $class]);
            }
            $allowed = null !== $owner;
            foreach ($options->moduleRoots as $root) {
                $allowed = $allowed || $root->contains($file);
            }
            if (!$allowed) {
                throw ArchitectureValidationException::fatal('discovery.module_boundary', 'Module descriptor "'.$class.'" is outside the allowed module discovery boundaries.', ['file' => $file, 'module' => $class]);
            }
            foreach ($modules as $known) {
                if ($directory === $known->directory || str_starts_with($directory.'/', $known->directory.'/') || str_starts_with($known->directory.'/', $directory.'/')) {
                    throw ArchitectureValidationException::fatal('discovery.module_overlap', 'Sillbeam descriptors have overlapping module areas: '.$class.' and '.$known->class, ['file' => $file, 'module' => $class]);
                }
            }
            $metadata = $this->inspector->metadata($class, $file, SillbeamModule::class);
            $modules[$class] = new ModuleDefinition(
                id: $metadata->id ?? IdDeriver::fromClass($class, 'Module', $file),
                class: $class,
                description: $metadata->description,
                dependencies: $metadata->dependencies,
                enabled: true,
                directory: $directory,
                descriptorFile: $file,
                namespace: $options->namespaceForDirectory($directory),
                entityDirectories: $this->inspector->directories($directory, $options->entityPatterns, options: $options),
                controllerDirectories: $this->inspector->directories($directory, $options->controllerPatterns, options: $options),
                projectClass: $owner,
            );
        }

        return $modules;
    }
}
